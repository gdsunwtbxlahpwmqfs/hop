# Apache Hop UI Icons Collection

All UI icon files collected from the Apache Hop project, organized by origin.

## Directory Structure

| Directory | Source | Count | Type |
|-----------|--------|-------|------|
| `ui/` | `ui/src/main/resources/ui/images/` | 202 | SVG |
| `auth/` | `ui/.../auth/resources/` | 3 | PNG |
| `core/` | `core/src/main/resources/images/` | 9 | SVG |
| `engine/` | `engine/.../images/` | 3 | SVG |
| `plugins/actions/` | `plugins/actions/*/src/main/resources/` | 65 | SVG |
| `plugins/transforms/` | `plugins/transforms/*/src/main/resources/` | 179 | SVG |
| `plugins/databases/` | `plugins/databases/*/src/main/resources/` | 25 | SVG |
| `plugins/tech/` | `plugins/tech/*/src/main/resources/` | 46 | SVG |
| `plugins/misc/` | `plugins/misc/*/src/main/resources/` | 45 | SVG |
| `plugins/engines/` | `plugins/engines/beam/` | 19 | SVG |
| `plugins/valuetypes/` | `plugins/valuetypes/uuid/` | 1 | SVG |
| `assemblies/` | `assemblies/static/src/main/resources/` | 14 | SVG+ICO |
| `_references/laf.properties` | Icon mapping config | 1 | Properties |

**Total: ~612 files**

## File Origin Summary

- **Toolbar/UI icons**: `myimages/ui/`
- **Data type icons**: `myimages/core/`
- **Pipeline transform nodes**: `myimages/plugins/transforms/`
- **Workflow action nodes**: `myimages/plugins/actions/`
- **Database connection icons**: `myimages/plugins/databases/`
- **Technology connector icons**: `myimages/plugins/tech/`
- **Miscellaneous plugin icons**: `myimages/plugins/misc/`
- **Beam engine icons**: `myimages/plugins/engines/`
- **Static web resources**: `myimages/assemblies/`
- **Icon path reference file**: `myimages/_references/laf.properties`
